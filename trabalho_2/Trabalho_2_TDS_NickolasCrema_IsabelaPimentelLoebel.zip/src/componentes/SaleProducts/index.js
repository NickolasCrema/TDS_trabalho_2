import Carousel from "../Carousel"
import "../NewProducts/NewProducts.css";

const SaleProducts = () => {
    return (
        <div className="listaProdutos">
            <div className="title">Ofertas</div>
            <Carousel/>
        </div>
    )
}

export default SaleProducts