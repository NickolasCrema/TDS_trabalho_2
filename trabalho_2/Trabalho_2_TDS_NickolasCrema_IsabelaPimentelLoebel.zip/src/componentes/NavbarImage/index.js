import './NavbarImage.css';

const NavbarImage = () => {
    return(
        <img className='navbar-image' src='/imagens/logo.png' alt='Logo'></img>
    )
}

export default NavbarImage