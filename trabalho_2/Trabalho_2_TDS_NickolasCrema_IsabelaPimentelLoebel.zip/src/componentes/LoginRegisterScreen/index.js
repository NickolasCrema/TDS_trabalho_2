import Footer from "../Footer"
import Header from "../Header"
import LoginRegisterBody from "../LoginRegisterBody"

const LoginRegisterScreen = () => {
    return(
        <div>
            <Header/>
            <LoginRegisterBody/>
            <Footer/>

        </div>
    )
}

export default LoginRegisterScreen